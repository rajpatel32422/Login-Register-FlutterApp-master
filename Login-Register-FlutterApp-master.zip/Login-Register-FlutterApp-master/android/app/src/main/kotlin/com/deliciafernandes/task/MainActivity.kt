package com.deliciafernandes.task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
